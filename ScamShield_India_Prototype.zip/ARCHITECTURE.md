# Technical Design
```text
Browser -> Flask app -> local message rules OR URL pattern checks -> result + safety advice
```
1. User submits a message or URL.
2. Flask calls local analysis functions.
3. The prototype checks patterns without fetching or opening the URL.
4. The result explains detected indicators and safe actions.

## Privacy and limitations
Avoid collecting personal information. A low-risk result is not proof of safety. Production use needs security review, privacy notices, rate limiting, accessible translations, validated models and user testing.

## Planned ML upgrade
Train TF-IDF + Logistic Regression/Linear SVM on a properly licensed labelled dataset. Evaluate with a held-out test set and precision, recall, F1-score, and confusion matrix.
