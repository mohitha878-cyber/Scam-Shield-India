# ScamShield India
**Tagline:** Detect the scam. Protect your future.  
**Theme:** Digital Safety & Cyber Fraud Awareness

A student educational web prototype that flags common suspicious patterns in SMS/WhatsApp text and URLs, explains the patterns, and gives English/Tamil safety guidance.

## Important limitations
- This is a transparent **rule-based baseline, not a trained or validated AI model**.
- A warning does not prove fraud; no warning does not prove safety.
- It does not open URLs or check live threat feeds.
- Do not enter real OTPs, passwords, bank details, or private messages.

## Run locally
1. Install Python 3.10+.
2. Run `pip install -r requirements.txt`.
3. Run `python app.py`.
4. Open `http://127.0.0.1:5000`.

## Tests
Run `pytest`.

## Structure
- `app.py`: Flask web application
- `scam_detector.py`: baseline text and URL indicators
- `templates/index.html`: interface
- `tests/test_scam_detector.py`: automated tests
- `sample_messages.csv`: sample examples
- `ARCHITECTURE.md`: design and data flow
- `TEST_CASES.md`: manual test plan

## Next steps
Evaluate against a properly licensed labelled dataset; then consider TF-IDF + Logistic Regression or Linear SVM. Report precision, recall, F1-score and a confusion matrix before claiming model performance. Review privacy, security, translations, and bias before public deployment.

For suspected cyber financial fraud in India, contact your bank promptly and consult official channels including `https://cybercrime.gov.in/` and helpline 1930. Verify current instructions from official sources.
