from flask import Flask, render_template, request
from scam_detector import analyze_message, analyze_url
app = Flask(__name__)
@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    message = request.form.get("message", "").strip() if request.method == "POST" else ""
    url = request.form.get("url", "").strip() if request.method == "POST" else ""
    if request.method == "POST":
        if message: result = analyze_message(message)
        elif url: result = analyze_url(url)
        else: result = {"label":"No input","risk":"Unknown","score":0,"reasons":["Paste a message or enter a URL."],"advice":"Never share OTPs, PINs, passwords, or banking details."}
    return render_template("index.html", result=result, message=message, url=url)
if __name__ == "__main__":
    app.run(debug=True)
