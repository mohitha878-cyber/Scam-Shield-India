# Manual test plan
- “Your account will be blocked. Share OTP immediately.” -> OTP and urgency indicators.
- “Congratulations, you won a prize. Click here.” -> prize/link indicators.
- “Hello, see you at 5 pm.” -> no obvious indicators, with safety caveat.
- `http://example.com` -> HTTP warning.
- `https://bit.ly/example` -> URL shortener warning.
- Empty form -> asks user for input.

These tests verify basic functionality, not real-world accuracy.
