from scam_detector import analyze_message, analyze_url

def test_otp_urgency_flags_message():
    result=analyze_message("Your account will be blocked. Share OTP immediately.")
    assert result["risk"] in ("Medium","High")
    assert any("OTP" in r for r in result["reasons"])

def test_normal_message_has_caveat():
    result=analyze_message("Hello, see you at 5 pm.")
    assert result["risk"]=="Low"
    assert any("does not prove" in r for r in result["reasons"])

def test_short_url_flagged():
    result=analyze_url("https://bit.ly/example")
    assert any("shortener" in r for r in result["reasons"])

def test_http_url_flagged():
    result=analyze_url("http://example.com")
    assert any("HTTPS" in r for r in result["reasons"])
