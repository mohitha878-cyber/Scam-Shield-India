"""Educational rule-based baseline; not a definitive fraud detector."""
import re
from urllib.parse import urlparse
RULES = [
 (r"\b(otp|one[- ]time password|pin)\b","Mentions OTP/PIN; never share these."),
 (r"\b(urgent|immediately|act now|within \d+ minutes)\b","Uses urgency or pressure."),
 (r"\b(prize|lottery|won|winner|reward)\b","Promises a prize or reward."),
 (r"\b(verify|suspend|blocked|account will be closed)\b","May imitate an account/security warning."),
 (r"\b(click here|claim now|update kyc)\b","Requests a click or account update."),
 (r"\b(send money|transfer|payment required|processing fee)\b","Requests money or a fee."),
 (r"\b(password|bank details|card number)\b","Requests sensitive information."),
]
SHORTENERS={"bit.ly","tinyurl.com","t.co","is.gd","cutt.ly","shorturl.at"}
def analyze_message(message):
    text=message.lower()
    reasons=[reason for pattern,reason in RULES if re.search(pattern,text)]
    if re.search(r"https?://|www\\.",text): reasons.append("Contains a link; inspect the destination carefully.")
    score=min(100,len(reasons)*22)
    label,risk=("Potential scam","High") if score>=45 else (("Suspicious indicators found","Medium") if score>=22 else ("No obvious indicators found","Low"))
    if not reasons: reasons=["No listed warning patterns detected. This does not prove the message is safe."]
    advice="Do not click suspicious links or share sensitive information. Verify via the organisation's official app/site. If money was lost in India, contact your bank and report at 1930 or cybercrime.gov.in."
    return {"label":label,"risk":risk,"score":score,"reasons":reasons,"advice":advice}
def analyze_url(url):
    candidate=url.strip()
    if not re.match(r"^https?://",candidate,re.I): candidate="https://"+candidate
    parsed=urlparse(candidate); host=(parsed.hostname or "").lower(); reasons=[]
    if not host: reasons.append("URL could not be parsed.")
    if parsed.scheme!="https": reasons.append("URL does not use HTTPS; HTTPS alone does not guarantee safety.")
    if host in SHORTENERS: reasons.append("Known URL shortener; destination is not shown here.")
    if host.startswith("xn--") or ".xn--" in host: reasons.append("Domain uses punycode characters; inspect carefully.")
    if re.search(r"\d{1,3}(?:\.\d{1,3}){3}",host): reasons.append("Host is an IP address rather than a familiar domain.")
    if len(host)>45 or host.count("-")>=3: reasons.append("Domain has unusual length or many hyphens.")
    score=min(100,len(reasons)*25)
    if score>=50: label,risk="Caution: suspicious URL patterns","High"
    elif score: label,risk="Review this URL carefully","Medium"
    else:
        label,risk="No obvious URL pattern flags","Unknown"
        reasons.append("No basic flags detected. This prototype does not verify sites or use live threat feeds.")
    advice="Do not enter passwords, OTPs, or payment details unless you independently verify the site. Type the official address yourself when unsure."
    return {"label":label,"risk":risk,"score":score,"reasons":reasons,"advice":advice}
